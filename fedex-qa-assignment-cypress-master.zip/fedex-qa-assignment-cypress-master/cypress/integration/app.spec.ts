/// <reference types="cypress" />

describe("write your cypress and mcoha tests here", () => {
  it("The start-wars app is open", () => {});
});
